package com.example.bhargav_marsonia_comp304_assignment_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class AIActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_i);
        TextView tv = (TextView) findViewById(R.id.textView2);
        tv.setText("AIActivity");
        tv.append(System.getProperty("line.separator"));
        tv.append(System.getProperty("line.separator"));
        tv.append("OnCreate Event Executed");

    }
    @Override
    protected void onStart(){
        super.onStart();
        TextView tv = (TextView) findViewById(R.id.textView2);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnStart Event Executed");
    }
    @Override
    public void onPause() {
        super.onPause();
        TextView tv = (TextView) findViewById(R.id.textView2);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnPause Event Executed");
    }
    @Override
    public void onResume() {
        super.onResume();
        TextView tv = (TextView) findViewById(R.id.textView2);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnResume Event Executed");
    }
    @Override
    public void onStop() {
        super.onStop();
        TextView tv = (TextView) findViewById(R.id.textView2);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnStop Event Executed");
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        TextView tv = (TextView) findViewById(R.id.textView2);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnDestroy Event Executed");
    }
    }