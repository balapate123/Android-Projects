package com.example.bhargav_marsonia_comp304_assignment_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Second_Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fragment = (Second_Fragment)getSupportFragmentManager()
                    .findFragmentById(R.id.fragment2);

        final ListView list_1 = (ListView) findViewById(R.id.list_1);

        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.setText("MainActivity");
        tv.append(System.getProperty("line.separator"));
        tv.append(System.getProperty("line.separator"));
        tv.append("OnCreate Event Executed");

        String[] activities = new String[]{
                "AIActivity",
                "VRActivity"
        };
        final List<String> active_list = new ArrayList<String>(Arrays.asList(activities));

        // Create an ArrayAdapter from List
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, active_list);

        // DataBind ListView with items from ArrayAdapter
        list_1.setAdapter(arrayAdapter);
        list_1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position==0){
                    Intent myIntent = new Intent(view.getContext(),AIActivity.class);
                    startActivityForResult(myIntent,0);
                }
                if (position==1){
                    Intent myIntent = new Intent(view.getContext(),VIActivity.class);
                    startActivityForResult(myIntent,1);
                }
            }
        });

    }

    @Override
    protected void onStart(){
        super.onStart();
        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnStart Event Executed");
    }
    @Override
    public void onPause() {
        super.onPause();
        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnPause Event Executed");
    }
    @Override
    public void onResume() {
        super.onResume();
        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnResume Event Executed");
    }
    @Override
    public void onStop() {
        super.onStop();
        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnStop Event Executed");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        TextView tv = (TextView) findViewById(R.id.textView3);
        tv.append(System.getProperty("line.separator"));
        tv.append(" OnDestroy Event Executed");
    }




}